package arhangel.dim.swing;

/**
 *
 */
public interface Observer {
    public void handleEvent();

}
